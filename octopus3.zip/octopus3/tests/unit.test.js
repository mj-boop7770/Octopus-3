const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const dns = require('dns');

const { evaluate, formatNumber } = require('../api/lib/calc.js');
const { isPrivateIp, fetchSafe, htmlToText } = require('../api/lib/safefetch.js');
const mem = require('../api/lib/memory.js');
const { needsDeliberation, parseVerdict, buildRevisionNote } = require('../api/lib/deliberate.js');
const { buildSystemPrompt } = require('../api/lib/soul.js');
const { validateAndSanitizeRequest } = require('../api/lib/securityLayer.js');

test('calculatrice : résultats exacts', () => {
  assert.equal(evaluate('1250 * 1.16'), 1450);
  assert.equal(evaluate('2 + 3 * 4'), 14);
  assert.equal(evaluate('(2 + 3) * 4'), 20);
  assert.equal(evaluate('2 ^ 3 ^ 2'), 512);
  assert.equal(evaluate('-2 ^ 2'), -4);
  assert.equal(evaluate('sqrt(144) + abs(-3)'), 15);
  assert.equal(evaluate('10 % 4'), 2);
  assert.equal(evaluate('5 × 3 ÷ 5'), 3);
  assert.equal(formatNumber(0.1 + 0.2), '0.3');
  assert.equal(formatNumber(evaluate('pi')), '3.14159265359');
});

test('calculatrice : refuse le dangereux et le mal formé', () => {
  for (const bad of ['', '1/0', '2 +', 'process.exit()', 'constructor', '((1)', '1 2', 'foo(3)', '1'.repeat(300), 'sqrt(-1)']) {
    assert.throws(() => evaluate(bad), undefined, `devrait refuser : ${bad.slice(0, 20)}`);
  }
});

test('SSRF : adresses privées reconnues', () => {
  for (const ip of ['127.0.0.1', '10.1.2.3', '192.168.0.5', '172.16.0.1', '172.31.255.255', '169.254.169.254', '100.64.0.1', '0.0.0.0', '::1', '::', 'fe80::1', 'fd00::1', '::ffff:127.0.0.1', '::ffff:7f00:1', 'pas-une-ip']) {
    assert.equal(isPrivateIp(ip), true, ip);
  }
  for (const ip of ['8.8.8.8', '1.1.1.1', '172.32.0.1', '2606:4700:4700::1111']) {
    assert.equal(isPrivateIp(ip), false, ip);
  }
});

test('SSRF : fetchSafe refuse les cibles internes', async () => {
  for (const url of ['http://127.0.0.1/', 'http://localhost/', 'http://169.254.169.254/latest/meta-data', 'file:///etc/passwd', 'https://example.com:8080/', 'http://[::1]/', 'http://user:pw@example.com/', 'ftp://example.com', 'pas une url', 'http://service.internal/']) {
    await assert.rejects(fetchSafe(url), undefined, url);
  }
});

test('SSRF : un nom de domaine qui pointe vers une IP interne est bloqué (DNS rebinding)', async () => {
  const original = dns.lookup;
  dns.lookup = (host, opts, cb) => { const f = typeof opts === 'function' ? opts : cb; f(null, [{ address: '127.0.0.1', family: 4 }]); };
  try {
    await assert.rejects(fetchSafe('http://evil.test/'), /non autoris/);
  } finally { dns.lookup = original; }
});

test('fetchSafe : lit une page (serveur local autorisé pour le test) et suit une redirection', async () => {
  const server = http.createServer((req, res) => {
    if (req.url === '/r') { res.writeHead(302, { Location: '/page' }); return res.end(); }
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end('<html><head><title>Titre &amp; test</title><style>x{}</style></head><body><script>alert(1)</script><p>Bonjour</p><p>monde</p></body></html>');
  });
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  try {
    const page = await fetchSafe(`http://127.0.0.1:${server.address().port}/r`, { allowPrivate: true });
    assert.equal(page.status, 200);
    const { title, text } = htmlToText(page.text);
    assert.equal(title, 'Titre & test');
    assert.match(text, /Bonjour/);
    assert.doesNotMatch(text, /alert/);
  } finally { server.close(); }
});

test('mémoire : filtre les secrets et nettoie', () => {
  assert.equal(mem.looksSensitive('Mon mot de passe est abc'), true);
  assert.equal(mem.looksSensitive('clé gsk_abcdefghijkl1234'), true);
  assert.equal(mem.looksSensitive('carte 4111 1111 1111 1111'), true);
  assert.equal(mem.looksSensitive('Il habite à Maputo et code sur mobile'), false);
  const clean = mem.sanitizeMemories([{ t: 'Aime le football', ts: 5 }, { t: 'password: x', ts: 1 }, 'Vit à Maputo', 42, null, { t: '' }]);
  assert.deepEqual(clean.map(m => m.t), ['Aime le football', 'Vit à Maputo']);
  assert.equal(mem.sanitizeMemories('nimporte quoi').length, 0);
});

test('mémoire : choisit les souvenirs pertinents', () => {
  const m = [
    { t: 'Construit une application de moto-taxi à Maputo', ts: 10 },
    { t: 'Aime le football et la Coupe du monde', ts: 5 },
    { t: 'Ancien rédacteur publicitaire', ts: 1 }
  ];
  const picked = mem.selectRelevant(m, 'Comment améliorer mon application de moto taxi ?');
  assert.equal(picked[0], 'Construit une application de moto-taxi à Maputo');
  assert.ok(picked.length <= 8);
  assert.deepEqual(mem.selectRelevant([], 'bonjour'), []);
});

test('mémoire : détecte quand extraire, dédoublonne', async () => {
  assert.equal(mem.shouldExtract('Je travaille sur une app de moto-taxi'), true);
  assert.equal(mem.shouldExtract('Quelle heure est-il ?'), false);
  assert.equal(mem.shouldExtract('Mon'), false);
  assert.deepEqual(mem.parseFacts('blabla {"facts":["a b c d e f g h","x"]} fin'), ['a b c d e f g h', 'x']);
  assert.deepEqual(mem.parseFacts('pas de json'), []);
  const add = mem.filterNewFacts(
    ["L'utilisateur construit une app de moto-taxi à Maputo", "L'utilisateur code sur un téléphone Xiaomi", 'mot de passe: 1234 5678 9012'],
    [{ t: 'Construit une app de moto-taxi à Maputo', ts: 1 }]
  );
  assert.deepEqual(add, ["L'utilisateur code sur un téléphone Xiaomi"]);
  const facts = await mem.extractFacts({
    userMessage: 'Je code sur mobile', answer: 'ok', existing: [], target: { provider: 'groq', apiKey: 'k', model: 'm' },
    completion: async () => '{"facts":["Code depuis un téléphone mobile"]}'
  });
  assert.deepEqual(facts, ['Code depuis un téléphone mobile']);
  const none = await mem.extractFacts({ userMessage: 'x', answer: 'y', existing: [], target: { provider: 'groq', apiKey: 'k', model: 'm' }, completion: async () => { throw new Error('panne'); } });
  assert.deepEqual(none, []);
});

test('délibération : quand réfléchir', () => {
  assert.equal(needsDeliberation({ text: 'salut', mode: 'standard' }), false);
  assert.equal(needsDeliberation({ text: 'Merci beaucoup !', mode: 'standard' }), false);
  assert.equal(needsDeliberation({ text: 'Pourquoi mon application plante quand je clique sur envoyer ?', mode: 'standard' }), true);
  assert.equal(needsDeliberation({ text: 'Combien font 1250*1.16 ?', mode: 'standard' }), true);
  assert.equal(needsDeliberation({ text: 'x'.repeat(300), mode: 'standard' }), true);
  assert.equal(needsDeliberation({ text: 'Pourquoi le ciel est bleu ? Explique', mode: 'concise' }), false);
  assert.equal(needsDeliberation({ text: 'Écris une fonction de tri', mode: 'code' }), true);
  assert.equal(needsDeliberation({ text: 'Décris cette photo en détail pour moi', mode: 'standard', hasImage: true }), false);
});

test('délibération : lit le verdict du relecteur', () => {
  const v = parseVerdict('Voici : {"verdict":"revise","confidence":0.4,"problems":["calcul faux"],"needs_fresh_info":true}');
  assert.deepEqual(v, { verdict: 'revise', confidence: 0.4, problems: ['calcul faux'], needs_fresh_info: true });
  assert.equal(parseVerdict('{"verdict":"peut-être"}'), null);
  assert.equal(parseVerdict('rien'), null);
  assert.equal(parseVerdict('{"verdict":"ok","confidence":7}').confidence, 1);
  assert.match(buildRevisionNote(v, { canSearch: true }), /calcul faux[\s\S]*outils web/);
});

test('âme : le prompt contient les principes, le modèle et les souvenirs', () => {
  const p = buildSystemPrompt({ mode: 'code', hasWebTool: true, memories: ['Vit à Maputo'], model: 'openai/gpt-oss-120b', now: new Date('2026-11-25T10:00:00Z') });
  assert.match(p, /Octopus/);
  assert.match(p, /2026-11-25/);
  assert.match(p, /gpt-oss-120b/);
  assert.match(p, /Vit à Maputo/);
  assert.match(p, /MODE CODE/);
  assert.match(p, /web_search/);
  assert.match(buildSystemPrompt({ hasWebTool: false }), /désactivée/);
});

test('sécurité : clés du client ignorées par défaut, souvenirs nettoyés', () => {
  const saved = { g: process.env.GROQ_API_KEY, a: process.env.ALLOW_CLIENT_KEYS };
  process.env.GROQ_API_KEY = 'serveur';
  delete process.env.ALLOW_CLIENT_KEYS;
  try {
    const d = validateAndSanitizeRequest({ messages: [{ role: 'user', content: 'salut' }], groqKey: 'pirate', memories: [{ t: 'Vit à Maputo', ts: 1 }, { t: 'password: x' }] }, { 'x-groq-key': 'pirate2' });
    assert.equal(d.keys.groq, 'serveur');
    assert.deepEqual(d.memories.map(m => m.t), ['Vit à Maputo']);
    process.env.ALLOW_CLIENT_KEYS = '1';
    assert.equal(validateAndSanitizeRequest({ messages: [{ role: 'user', content: 'x' }], groqKey: 'test' }).keys.groq, 'test');
    delete process.env.GROQ_API_KEY; delete process.env.OPENROUTER_API_KEY; delete process.env.ALLOW_CLIENT_KEYS;
    assert.throws(() => validateAndSanitizeRequest({ messages: [{ role: 'user', content: 'x' }] }), /Aucune clé/);
  } finally {
    if (saved.g === undefined) delete process.env.GROQ_API_KEY; else process.env.GROQ_API_KEY = saved.g;
    if (saved.a === undefined) delete process.env.ALLOW_CLIENT_KEYS; else process.env.ALLOW_CLIENT_KEYS = saved.a;
  }
});

test('évaluations : le barème repère les bonnes et mauvaises réponses', () => {
  const { score } = require('../evals/run.js');
  const cases = require('../evals/cases.json');
  assert.ok(cases.length >= 10);
  for (const c of cases) { for (const re of [...(c.expect || []), ...(c.forbid || [])]) new RegExp(re, 'im'); }
  const calcul = cases.find(c => c.id === 'calcul');
  assert.equal(score(calcul, '17,5 % de 2 340 = 409,5 MZN').pass, true);
  assert.equal(score(calcul, 'Environ 400').pass, false);
  const hall = cases.find(c => c.id === 'pas-d-invention');
  assert.equal(score(hall, "Je ne connais pas cette thèse, je ne peux pas l'inventer.").pass, true);
  assert.equal(score(hall, 'Voir page 42 du manuscrit.').pass, false);
  const hi = cases.find(c => c.id === 'salutation-courte');
  assert.equal(score(hi, 'Salut ! Que puis-je faire pour toi ?').pass, true);
  assert.equal(score(hi, 'x'.repeat(500)).pass, false);
  assert.equal(score(hi, '').pass, false);
});
