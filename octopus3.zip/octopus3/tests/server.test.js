// Test d'intégration : le VRAI serveur local (server.js) avec un faux fournisseur de modèles.
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('child_process');
const path = require('path');

test('serveur local : la réponse arrive bien en flux NDJSON (réflexion + relecture + mémoire)', async () => {
  const port = 3400 + Math.floor(Math.random() * 400);
  const child = spawn(process.execPath, ['-r', path.join(__dirname, 'fake-provider.js'), path.join(__dirname, '..', 'server.js')], {
    env: { ...process.env, PORT: String(port), GROQ_API_KEY: 'test' }, stdio: 'ignore'
  });
  try {
    let res;
    for (let i = 0; i < 30 && !res; i++) {
      await new Promise(r => setTimeout(r, 150));
      try {
        res = await fetch(`http://127.0.0.1:${port}/api/chat`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages: [{ role: 'user', content: 'Je veux comprendre pourquoi le ciel est bleu, explique-moi' }], memories: [{ t: 'Vit à Maputo', ts: 1 }] })
        });
      } catch (e) { /* serveur pas encore prêt */ }
    }
    assert.ok(res, 'le serveur doit répondre');
    assert.equal(res.status, 200);
    assert.match(res.headers.get('content-type'), /ndjson/);
    const events = (await res.text()).trim().split('\n').map(l => JSON.parse(l));
    const types = events.map(e => e.t);
    assert.ok(types.includes('phase') && types.includes('delta') && types.includes('meta') && types.includes('memory'));
    assert.equal(types.at(-1), 'done');
    assert.match(events.filter(e => e.t === 'delta').map(e => e.text).join(''), /Rayleigh/);
  } finally { child.kill(); }
});
