const sse = (t) => new Response(new ReadableStream({ start(c) { const e = new TextEncoder(); for (let i = 0; i < t.length; i += 9) c.enqueue(e.encode('data: ' + JSON.stringify({ choices: [{ delta: { content: t.slice(i, i + 9) } }] }) + '\n\n')); c.enqueue(e.encode('data: [DONE]\n\n')); c.close(); } }));
global.fetch = async (url, opt) => {
  const b = JSON.parse(opt.body); const sys = b.messages[0].content;
  if (b.stream) return sse('Parce que la lumière bleue est diffusée plus fort (Rayleigh).');
  const content = /relecteur/.test(sys) ? '{"verdict":"ok","confidence":0.88,"problems":[]}' : '{"facts":["Veut comprendre la physique du ciel"]}';
  return new Response(JSON.stringify({ choices: [{ message: { content } }] }));
};
