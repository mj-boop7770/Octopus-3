const test = require('node:test');
const assert = require('node:assert/strict');

process.env.GROQ_API_KEY = 'test';
delete process.env.TAVILY_API_KEY;
const { runAgent } = require('../api/lib/agent.js');

const sseResponse = ({ text = '', toolCalls = [] }) => new Response(new ReadableStream({
  start(c) {
    const enc = new TextEncoder();
    const send = (o) => c.enqueue(enc.encode('data: ' + JSON.stringify(o) + '\n\n'));
    if (text) for (let i = 0; i < text.length; i += 7) send({ choices: [{ delta: { content: text.slice(i, i + 7) } }] });
    toolCalls.forEach((t, index) => send({ choices: [{ delta: { tool_calls: [{ index, id: t.id, function: { name: t.name, arguments: JSON.stringify(t.args) } }] } }] }));
    c.enqueue(enc.encode('data: [DONE]\n\n')); c.close();
  }
}), { status: 200 });
const jsonResponse = (content) => new Response(JSON.stringify({ choices: [{ message: { content } }] }), { status: 200 });

// `script` reçoit { kind: 'main'|'critic'|'memory', body, n } et renvoie une Response
async function run(script, input) {
  const log = [];
  let n = 0;
  global.fetch = async (url, opt) => {
    const body = JSON.parse(opt.body);
    const sys = (body.messages[0] && body.messages[0].content) || '';
    const kind = body.stream ? 'main' : /relecteur interne/.test(sys) ? 'critic' : /module de mémoire/.test(sys) ? 'memory' : 'other';
    n += 1;
    log.push({ kind, body });
    return script({ kind, body, n, count: log.filter(l => l.kind === kind).length });
  };
  const events = [];
  await runAgent({ keys: { groq: 'k' }, mode: 'standard', webSearch: false, hasImage: false, file: null, memories: [], emit: (e) => events.push(e), ...input });
  return { events, log, text: events.filter(e => e.t === 'delta').map(e => e.text).join(''), types: events.map(e => e.t) };
}
const U = (content) => [{ role: 'user', content }];

test('question simple : réponse directe, sans relecture', async () => {
  const r = await run(() => sseResponse({ text: 'Salut ! Comment puis-je aider ?' }), { messages: U('salut') });
  assert.equal(r.text, 'Salut ! Comment puis-je aider ?');
  assert.deepEqual(r.log.map(l => l.kind), ['main']);
  assert.ok(!r.types.includes('phase'));
  assert.equal(r.types.at(-1), 'done');
});

test('question difficile : brouillon silencieux, relecture ok, livraison + méta', async () => {
  const r = await run(({ kind }) => kind === 'critic'
    ? jsonResponse('{"verdict":"ok","confidence":0.92,"problems":[],"needs_fresh_info":false}')
    : sseResponse({ text: 'Le ciel est bleu à cause de la diffusion de Rayleigh.' }),
    { messages: U('Pourquoi le ciel est bleu ? Explique clairement.') });
  assert.deepEqual(r.log.map(l => l.kind), ['main', 'critic']);
  assert.equal(r.text, 'Le ciel est bleu à cause de la diffusion de Rayleigh.');
  assert.deepEqual(r.events.filter(e => e.t === 'phase').map(e => e.name), ['think', 'check']);
  const meta = r.events.find(e => e.t === 'meta');
  assert.deepEqual([meta.checked, meta.revised, meta.confidence], [true, false, 0.92]);
  // le brouillon ne doit pas être diffusé avant la fin de la relecture
  assert.ok(r.types.indexOf('delta') > r.types.indexOf('phase'));
});

test('relecteur trouve un défaut : réécriture, seule la version corrigée est affichée', async () => {
  const r = await run(({ kind, count }) => kind === 'critic'
    ? jsonResponse('{"verdict":"revise","confidence":0.3,"problems":["Le calcul est faux"],"needs_fresh_info":false}')
    : sseResponse({ text: count === 1 ? 'Brouillon faux : 1450' : 'Version corrigée : 1450,00 MZN' }),
    { messages: U('Combien coûte 1250 avec 16% de TVA ? Explique.') });
  assert.deepEqual(r.log.map(l => l.kind), ['main', 'critic', 'main']);
  assert.equal(r.text, 'Version corrigée : 1450,00 MZN');
  assert.doesNotMatch(r.text, /Brouillon/);
  const second = r.log[2].body.messages;
  assert.match(second.at(-1).content, /CONTRÔLE QUALITÉ[\s\S]*calcul est faux/);
  assert.equal(second.at(-2).content, 'Brouillon faux : 1450');
  assert.deepEqual(r.events.filter(e => e.t === 'phase').map(e => e.name), ['think', 'check', 'revise']);
  const meta = r.events.find(e => e.t === 'meta');
  assert.equal(meta.revised, true);
});

test('relecteur en panne : le brouillon est livré tel quel, marqué non vérifié', async () => {
  const r = await run(({ kind }) => kind === 'critic' ? new Response('boom', { status: 500 }) : sseResponse({ text: 'Réponse sans relecture.' }),
    { messages: U('Pourquoi la mer est salée ? Explique.') });
  assert.equal(r.text, 'Réponse sans relecture.');
  const meta = r.events.find(e => e.t === 'meta');
  assert.deepEqual([meta.checked, meta.confidence], [false, null]);
  assert.equal(r.types.at(-1), 'done');
});

test('outil calculate : le modèle l\'appelle, le résultat exact lui revient', async () => {
  const r = await run(({ kind, body }) => {
    if (kind === 'critic') return jsonResponse('{"verdict":"ok","confidence":0.95}');
    const hasTool = body.messages.some(m => m.role === 'tool');
    return hasTool ? sseResponse({ text: 'Cela fait 1450.' }) : sseResponse({ toolCalls: [{ id: 'c1', name: 'calculate', args: { expression: '1250 * 1.16' } }] });
  }, { messages: U('Combien font 1250*1.16 ?') });
  const toolMsg = r.log.find(l => l.kind === 'main' && l.body.messages.some(m => m.role === 'tool')).body.messages.find(m => m.role === 'tool');
  assert.match(toolMsg.content, /= 1450$/);
  assert.equal(r.text, 'Cela fait 1450.');
  assert.deepEqual(r.events.filter(e => e.t === 'tool_done').map(e => e.ok), [true]);
  assert.match(r.events.find(e => e.t === 'tool').label, /Calcul/);
});

test('mémoire : nouveau souvenir proposé après une confidence durable', async () => {
  const r = await run(({ kind }) => kind === 'memory'
    ? jsonResponse('{"facts":["Construit une application de moto-taxi à Maputo"]}')
    : sseResponse({ text: 'Super projet !' }),
    { messages: U('Je construis une app de moto-taxi à Maputo') });
  const mem = r.events.find(e => e.t === 'memory');
  assert.deepEqual(mem.add, ['Construit une application de moto-taxi à Maputo']);
  assert.equal(r.types.at(-1), 'done');
});

test('mémoire : pas d\'appel d\'extraction pour une question banale', async () => {
  const r = await run(() => sseResponse({ text: 'Il est midi.' }), { messages: U('Quelle heure est-il ?') });
  assert.deepEqual(r.log.map(l => l.kind), ['main']);
});

test('mémoire : les souvenirs pertinents sont injectés dans le prompt', async () => {
  const r = await run(() => sseResponse({ text: 'Voici des idées.' }), {
    messages: U('Des idées pour mon application de moto taxi ?'),
    memories: [{ t: 'Construit une application de moto-taxi à Maputo', ts: 9 }, { t: 'Aime le football', ts: 1 }]
  });
  assert.equal(r.events[0].t, 'recall');
  assert.match(r.log[0].body.messages[0].content, /moto-taxi à Maputo/);
});

test('repli : si le premier modèle est saturé, le suivant répond', async () => {
  const r = await run(({ body }) => body.model === 'openai/gpt-oss-120b' ? new Response('limite', { status: 429 }) : sseResponse({ text: 'Réponse de secours.' }),
    { messages: U('salut') });
  assert.equal(r.text, 'Réponse de secours.');
  assert.equal(r.events.at(-1).model, 'openai/gpt-oss-20b');
});

test('repli en mode réflexion : un modèle saturé ne casse pas le brouillon silencieux', async () => {
  const r = await run(({ kind, body }) => {
    if (kind === 'critic') return jsonResponse('{"verdict":"ok","confidence":0.8}');
    return body.model === 'openai/gpt-oss-120b' ? new Response('limite', { status: 429 }) : sseResponse({ text: 'Réponse via le 20b.' });
  }, { messages: U('Pourquoi le ciel est bleu ? Explique.') });
  assert.equal(r.text, 'Réponse via le 20b.');
  assert.ok(!r.types.includes('error'));
});

test('tous les modèles saturés : un seul message d\'erreur clair, pas de « done »', async () => {
  const r = await run(() => new Response('limite', { status: 429 }), { messages: U('salut') });
  assert.deepEqual(r.types, ['error']);
  assert.match(r.events[0].message, /saturés/);
});
