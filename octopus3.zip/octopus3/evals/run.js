// evals/run.js — Mesure si Octopus progresse.
// Usage :  GROQ_API_KEY=... node evals/run.js          (toutes les questions)
//          GROQ_API_KEY=... node evals/run.js calcul   (une seule, par id)
// Compare les scores AVANT / APRÈS chaque modification de soul.js, deliberate.js, etc.

const fs = require('fs');
const path = require('path');

function score(testCase, text) {
  const failures = [];
  const t = String(text || '');
  for (const re of testCase.expect || []) if (!new RegExp(re, 'im').test(t)) failures.push(`manque /${re}/`);
  for (const re of testCase.forbid || []) if (new RegExp(re, 'im').test(t)) failures.push(`interdit /${re}/`);
  if (testCase.maxChars && t.length > testCase.maxChars) failures.push(`trop long (${t.length} > ${testCase.maxChars})`);
  if (!t.trim()) failures.push('réponse vide');
  return { pass: failures.length === 0, failures };
}

async function main() {
  const { runAgent } = require('../api/lib/agent.js');
  const only = process.argv[2];
  const cases = JSON.parse(fs.readFileSync(path.join(__dirname, 'cases.json'), 'utf8')).filter(c => !only || c.id === only);
  const keys = { groq: process.env.GROQ_API_KEY, openrouter: process.env.OPENROUTER_API_KEY };
  if (!keys.groq && !keys.openrouter) { console.error('Définis GROQ_API_KEY (ou OPENROUTER_API_KEY).'); process.exit(1); }

  const results = [];
  for (const c of cases) {
    const events = [];
    const started = Date.now();
    await runAgent({ messages: [{ role: 'user', content: c.prompt }], keys, mode: c.mode || 'standard', webSearch: false, hasImage: false, file: null, memories: [], emit: (e) => events.push(e) });
    const text = events.filter(e => e.t === 'delta').map(e => e.text).join('');
    const error = events.find(e => e.t === 'error');
    const r = error ? { pass: false, failures: [`erreur : ${error.message}`] } : score(c, text);
    results.push({ id: c.id, ...r, ms: Date.now() - started, answer: text.slice(0, 400) });
    console.log(`${r.pass ? 'OK  ' : 'ÉCHEC'} ${c.id.padEnd(24)} ${((Date.now() - started) / 1000).toFixed(1)}s ${r.failures.join(' ; ')}`);
    await new Promise(res => setTimeout(res, 2500)); // respecte les limites du plan gratuit
  }
  const passed = results.filter(r => r.pass).length;
  console.log(`\nScore : ${passed}/${results.length}`);
  fs.writeFileSync(path.join(__dirname, 'last-run.json'), JSON.stringify({ date: new Date().toISOString(), passed, total: results.length, results }, null, 2));
}

module.exports = { score };
if (require.main === module) main().catch(e => { console.error(e); process.exit(1); });
